"""Exposes version constant to avoid circular dependencies."""

VERSION = "3.2.0"
