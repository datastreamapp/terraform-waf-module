"""
Typing for developer ease in the IDE
"""

from .lambda_context import LambdaContext

__all__ = ["LambdaContext"]
